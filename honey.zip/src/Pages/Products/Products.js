import React from 'react'
import "./Products.css"
import { OurProducts } from "../../Components/Our Products/OurProducts"
import imgg from '../../Assets/Images/background.jpg'

export function Products() {
    return (
        <div id='products-main-conatainer'>
            <OurProducts />
        </div>
    )
}
