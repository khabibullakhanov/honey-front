import React from 'react'
import "./Orders.css"



export function Orders() {
  return (
    <div>Orders</div>
  )
}
